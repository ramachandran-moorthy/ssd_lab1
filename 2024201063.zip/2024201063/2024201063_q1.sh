#!/bin/bash
grep -e 'POST.*404' access.log

Q1:
Used the grep command with -e to filter the results based on the given constraints.

Q2:
Used the awk command with -F to set the delimiter to ',' instead of ' ' and then wrote a code to sum the values at the 4th index in every line.

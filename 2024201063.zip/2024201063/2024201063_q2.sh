#!/bin/bash
awk -F ',' '{ max += $4 } END { print max }' power_levels.txt
